For all the code files, goto https://github.com/Syncla/CPEG324/tree/master/lab1
It contains all of the code as we worked on the lab, beyond what was necessary for the submission